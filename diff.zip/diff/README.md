# lightdm-theme-micno
Sapphire LightDM Webkit Theme (Archive) をMicnoLinux向けのイメージに差し替えたものです。
