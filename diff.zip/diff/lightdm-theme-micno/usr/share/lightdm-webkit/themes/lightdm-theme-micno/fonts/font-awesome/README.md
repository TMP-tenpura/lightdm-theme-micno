# Font Awesome

Font Awesome Free v5.3.1 by @fontawesome - [https://fontawesome.com](https://fontawesome.com)

#License 

[https://fontawesome.com/license/free](https://fontawesome.com/license/free) (Icons: CC BY 4.0, 
Fonts: SIL OFL 1.1, Code: MIT License)
